using UnityEngine;

public class PlayerController : MonoBehaviour
{

    public float moveSpeed;
    public float maxSpeed;
    public float jumpForce;
    public float groundCheckRadius;
    public float horizontalInput;
    public bool isGrounded;
    public Transform groundCheck;
    public LayerMask groundLayer;
    private Rigidbody rb;


    private void Awake()
    {
        rb = GetComponent<Rigidbody>();
    }


    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        horizontalInput = Input.GetAxisRaw("Horizontal");


        if (isGrounded == true && Input.GetAxisRaw("Jump") > 0)
        {
            Jump();
        }


    }

    private void FixedUpdate()
    {
        isGrounded = Physics.CheckSphere(groundCheck.position, groundCheckRadius, groundLayer);

        Vector3 velocity = rb.linearVelocity;

        float targetVelX = horizontalInput * moveSpeed;

        float newVelX = Mathf.MoveTowards(velocity.x, targetVelX, 50f * Time.fixedDeltaTime);
        rb.linearVelocity = new Vector3(Mathf.Clamp(newVelX, -maxSpeed,maxSpeed), velocity.y, 0f);


    }


    void Jump()
    {
        Vector3 velocity = rb.linearVelocity;

        velocity.y = 0;

        rb.linearVelocity = velocity;
        rb.AddForce(Vector3.up * jumpForce, ForceMode.VelocityChange);

        


    }
}
