using UnityEngine;

public class EyeKiller : MonoBehaviour
{

    float timer = 0;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
         timer += Time.deltaTime;


        if (timer >= 0.01)
        {
            this.gameObject.GetComponent<MeshRenderer>().material.color = new Color(50, 54, 202);

            timer = 0;
        }
        else
        {
            this.gameObject.GetComponent<MeshRenderer>().material.color = new Color(0, 204, 102);
        }


           



       
    }
}
