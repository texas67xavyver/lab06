using UnityEngine;
[RequireComponent(typeof(Collider))]

public class Token : MonoBehaviour
{
    public int value;

    public AudioClip pickupSfx;


    private void Awake()
    {
        Collider collider = GetComponent<Collider>();

        collider.isTrigger = true;
    }


    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            if(UiManager.Instance != null)
            {
                UiManager.Instance.AddScore(value);
            }


            AudioSource.PlayClipAtPoint(pickupSfx, transform.position);
            Destroy(gameObject);
        }
    }
}

