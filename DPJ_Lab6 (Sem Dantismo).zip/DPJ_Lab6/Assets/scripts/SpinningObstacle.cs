using UnityEngine;
using UnityEngine.UIElements;

public class SpinningObstacle : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created



    [SerializeField] private float zAngle, xAngle, yAngle = 0f;
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        this.gameObject.transform.Rotate(xAngle, yAngle, zAngle, Space.Self);
    }
}
