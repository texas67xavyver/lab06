using TMPro;
using UnityEngine;

public class UiManager : MonoBehaviour


{

    public static UiManager Instance
    {
        get; private set;
    }



        // Start is called once before the first execution of Update after the MonoBehaviour is created

        [SerializeField] private TMP_Text scoreText, livesText;

    public int startLives = 3;

    public int score = 0;

    private int lives;


    private void Awake()
    {


        if (Instance != null)
        {
            Destroy(gameObject);
            return;
        }

        lives = startLives;




        UpdateScoreUI();
        UpdateLivesUI();

        Instance = this;
    }


    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
  
    }


    void UpdateScoreUI()
    {
        scoreText.text = $"score: {score}";
    }

    void UpdateLivesUI()
    {
        livesText.text = $"lives: {lives}";
    }

   public void AddScore(int amount)
    {
        score += amount;
        UpdateScoreUI();
    }

    void SetLives(int newlives)
    {
        lives = newlives;
        UpdateLivesUI();
    }
}
